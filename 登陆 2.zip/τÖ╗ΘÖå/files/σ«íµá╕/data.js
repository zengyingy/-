﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,_(j,k),l,[m,n,o,p,q,r,s],t,_(u,v,w,x,y,z,A,_(),B,_(C,D,E,F,G,_(H,I,J,K),L,null,M,F,N,F,O,P,Q,null,R,S,T,U,V,W,X,S),Y,_(),Z,_(),ba,_(bb,[])),bc,_(),bd,_());}; 
var b="url",c="审核.html",d="generationDate",e=new Date(1543674688994.81),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="sketchKeys",j="",k="s0",l="variables",m="course1",n="jiaocai",o="zuozhi",p="bianhao",q="beizhu",r="shenhejindu",s="changdu",t="page",u="packageId",v="0d6f985055b04db5a840865d8f526c56",w="type",x="Axure:Page",y="name",z="审核",A="notes",B="style",C="baseStyle",D="627587b6038d43cca051c114ac41ad32",E="pageAlignment",F="near",G="fill",H="fillType",I="solid",J="color",K=0xFFFFFFFF,L="image",M="imageHorizontalAlignment",N="imageVerticalAlignment",O="imageRepeat",P="auto",Q="favicon",R="sketchFactor",S="0",T="colorStyle",U="appliedColor",V="fontName",W="Applied Font",X="borderWidth",Y="adaptiveStyles",Z="interactionMap",ba="diagram",bb="objects",bc="masters",bd="objectPaths";
return _creator();
})());